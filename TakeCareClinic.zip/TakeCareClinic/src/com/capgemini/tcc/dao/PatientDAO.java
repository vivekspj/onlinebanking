package com.capgemini.tcc.dao;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dbutil.Dbutil;
import com.capgemini.tcc.patientexception.PatientException;


public class PatientDAO implements IPatientDAO {
	
	Logger log=Logger.getRootLogger();
	
	public PatientDAO(){
		BasicConfigurator.configure();
	}
	@Override
	public int addPatient(PatientBean p) throws PatientException {
		Connection conn=Dbutil.getConn();
		int n=0,c=0;
		ResultSet rs =null;
		
		try {
			
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			pstmt.setString(1, p.getPatientName());
			pstmt.setInt(2, p.getPatientAge());
			pstmt.setString(3, p.getPhoneNumber());
			pstmt.setString(4, p.getDescription());
			
			n=pstmt.executeUpdate();
			if(n==1)
			{
				PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.VIEW_SEQ);
				rs=pstmt1.executeQuery();
				rs.next();
				c=rs.getInt(1);	
			}
			if(n==0)
			{
				log.error("Intersion failed");
				System.err.println("Failed Insertion");
				return c;
			}
			else
			{
				//log.info("Intersion Successful");
				return c;
			}
			
			
		} catch (SQLException e1) {
			log.error("Database Problem: Data not Inserted");
			throw new PatientException("problem : "+e1.getMessage());
		}
		
	}

}
