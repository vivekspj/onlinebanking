package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.patientexception.PatientException;

public interface IPatientDAO {
	
	public int addPatient(PatientBean p) throws PatientException;

}
