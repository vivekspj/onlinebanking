package com.capgemini.tcc.dao;

public interface IQueryMapper {
		public static final String INSERT_QUERY="INSERT INTO patient values(Patient_Id_Seq.NEXTVAL,?,?,?,?,SYSDATE)";
		public static final String VIEW_SEQ="SELECT Patient_Id_Seq.currval from dual";

}
