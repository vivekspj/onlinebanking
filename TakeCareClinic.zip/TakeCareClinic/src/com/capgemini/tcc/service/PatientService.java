package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.patientexception.PatientException;

public class PatientService implements IPatientService {

	PatientDAO dao = new PatientDAO();
	@Override
	public int addPatient(PatientBean p) throws PatientException {
		return dao.addPatient(p);
	}

}
