package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.patientexception.PatientException;

public interface IPatientService {

	public int addPatient(PatientBean p) throws PatientException;
}
