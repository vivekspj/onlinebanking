package com.capgemini.tcc.bean;

public class PatientBean {
	private int patientID;
	private String patientName;
	private int patientAge;
	private String phoneNumber;
	private String description;

	//getter and setter method
	public int getPatientID() {
		return patientID;
	}

	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getPatientAge() {
		return patientAge;
	}

	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	//Parameterize Constructor
	public PatientBean(int patientID, String patientName, int patientAge,
			String phoneNumber, String description) {
		super();
		this.patientID = patientID;
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.phoneNumber = phoneNumber;
		this.description = description;
	}

	//Default Constructor
	public PatientBean() {
		
	}

}
