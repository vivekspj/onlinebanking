package com.capgemini.tcc.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;

public class PatientTest {

	PatientBean p = new PatientBean();
	@Test
	public void testPatientID() {
		p.setPatientID(1021);
		assertEquals("1021",p.getPatientID());
	}
	
	public void testPatientName() {
		p.setPatientName("King");
		assertEquals("aka",p.getPatientName());
	}

}
