package com.capgemini.tcc.ui;
import java.util.Scanner;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.patientexception.PatientException;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		Logger log=Logger.getRootLogger();
		BasicConfigurator.configure();
		PatientService service=new PatientService();
		PatientBean p = new PatientBean();
		
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		int choice;
		String patientName;
		int patientAge;
		String phoneNumber;
		String description;
		System.out.println("Select Your Choice");
		System.out.println("*******************");
		System.out.println("1. Add Patient Information");
		System.out.println("2. Exit");
		System.out.println("*******************");
		choice = scanner.nextInt();
		switch(choice)
		{
		//Collecting basics information of the Patient 
		case 1:System.out.print("Enter the name of the Patient:");
				patientName = scanner.next();
				
				System.out.print("Enter Patient Age:");
				patientAge = scanner.nextInt();
				System.out.print("Enter Patient phone number:");
				phoneNumber = scanner.next();
				System.out.print("Enter Description:");
				description = scanner.next();
				//calling bean methods to set bean variables
					p.setPatientName(patientName);
				    p.setPatientAge(patientAge);
				    p.setPhoneNumber(phoneNumber);
				    p.setDescription(description);		
				    
				    
				    try {
						int status=new Client().addPatient(p);
						if(status !=0 ){
							//log.info("Patient Information Added");
							//printing patientID using sequence
							System.out.println("Patient ID is "+service.addPatient(p));
						}
						else {
							log.error("No Patient Info Added");
						}
					} catch (PatientException e) {
						System.err.println("exception: "+e.getMessage());
					}
			
			break;
			
			
		case 2:System.exit(0);
		break;
		}

	}

	PatientService ps = null;
	private int addPatient(PatientBean p) throws PatientException{
		ps=new PatientService();
		return ps.addPatient(p);
	}

}
